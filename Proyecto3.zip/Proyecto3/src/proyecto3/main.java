package proyecto3;
import org.sqlite.Function;
import java.sql.*;

/**
 *
 * @author erasmo
 */
public class main {

    public static void main(String[] args) throws Exception{
        
        Connection cn = null;
        try{
            Class.forName("org.sqlite.JDBC");
            cn= DriverManager.getConnection("jdbc:sqlite:test.db");
            System.out.println("SQLite DB Connected");
            Statement statement = cn.createStatement();
            statement.setQueryTimeout(5000); //Aqui podemos ver la conexion a mi base de datos.
            
            //MOD
            Function.create(cn, "MOD", new MOD());
            statement.execute("select MOD(5,3)");
            System.out.println("MOD:\n" + statement.getResultSet().getDouble(1) + "\n");//aqui utilizamos la funcion MOD creada por nosotros
            //PV
            //No logre hacer funcion PV
            //BIN2DEC
            Function.create(cn, "BIN2DEC", new BIN2DEC());
            statement.execute("select BIN2DEC('10000')");
            System.out.println("BIN2DEC:\n"+statement.getResultSet().getInt(1) + "\n");//aqui utilizamos la funcion BIN2DEC
            //DEC2BIN
            Function.create(cn, "DEC2BIN", new DEC2BIN());
            statement.execute("select DEC2BIN('255')");
            System.out.println("DEC2BIN:\n" + statement.getResultSet().getString(1) + "\n");//aqui utilizamos la funcion DEC2BIN
            //C2F
            Function.create(cn, "C2F", new C2F());
            statement.execute("select C2F(100)");
            System.out.println("C2F:\n" + statement.getResultSet().getDouble(1) + "\n");//aqui utilizamos la funcion C2F
            //F2C
            Function.create(cn, "F2C", new F2C());
            statement.execute("select F2C(212)");
            System.out.println("F2C:\n" + statement.getResultSet().getInt(1) + "\n");//aqui utilizamos la funcion F2C
            //Factorial
            Function.create(cn, "Factorial", new Factorial());
            statement.execute("select Factorial(6)");
            System.out.println("Factorial:\n" + statement.getResultSet().getLong(1) + "\n");//aqui utilizamos la funcion Factorial
            //HEX2DEC
            Function.create(cn, "HEX2DEC", new HEX2DEC());
            statement.execute("select HEX2DEC('aabbccdd')");
            System.out.println("HEX2DEC:\n" + statement.getResultSet().getLong(1) + "\n");//aqui utiliamos la funcion HEX2DEC
            //DEC2HEX
            Function.create(cn, "DEC2HEX", new DEC2HEX());
            statement.execute("select DEC2HEX(15)");
            System.out.println("DEC2HEX:\n" + statement.getResultSet().getString(1) + "\n");//Aqui utilizamos la funcion DEC2HEX
            //COMPARESTRING
            Function.create(cn, "COMPARESTRING", new COMPARESTRING());
            statement.execute("select COMPARESTRING('App','Apaaap')");
            System.out.println("COMPARESTRING:\n"+statement.getResultSet().getInt(1) + "\n");//aqui utilizamos COMPARESTRING
            //TRIM
            Function.create(cn, "TRIM", new TRIM());
            statement.execute("select TRIM('aahola como te llamasaa','aa')");
            System.out.println("TRIM:\n" + statement.getResultSet().getString(1) + "\n");//aqui utilizamos TRIM
            //MID
            
        }
        catch(Exception e){
            System.out.println(e);
        }
    }
}

//MOD, esta es la funcion MOD
class MOD extends Function{
    @Override
    protected void xFunc() throws SQLException{
        try{
            double num1 = value_double(0);//creamos dos doubles
            double num2 = value_double(1);
            double res = num1 % num2;//sacamos num1 mod de num2 y lo guardamos en una variable double
            result(res);//retornamos el resultado
        }catch (Exception e){
            System.out.println(e);
        }
        
    }
}
//PV, no logre hacerla
            
//BIN2DEC, funcion BIN2DEC
class BIN2DEC extends Function{
    @Override
    protected void xFunc() throws SQLException {
        try {
            String bin = value_text(0);//creamos un string
            int binario = Integer.parseInt(bin);//luego casteamos ese string a int y lo guardamos en una variable
            int m = 0;

            int l = 0;
            int d = 0;

            while (binario != 0){//while binario sea distinto de 0 empezamos ecuaciones matematicas para sacar los mods del numero

                d = binario % 10;

                d *= Math.pow(2, l++);

                binario /= 10;

                m += d;
            }
            result(m);//luego devolvemos m como resultado
        }catch (Exception e){
            System.out.println(e);
        }
    }
}   
//DEC2BIN, funcion DEC2BIN
class DEC2BIN extends Function{
    @Override
    protected void xFunc() throws SQLException {
        try {
            int decimal = value_int(0);//creamos un int
            result(Integer.toBinaryString(decimal));//luego casteamos ese int a binary string y lo devolvemos
        }catch (Exception e){
            System.out.println(e);
        }
    }
}
//C2F, funcion C2F
class C2F extends Function{
    @Override
    protected void xFunc() throws SQLException {
        try {
            double celsius = value_double(0);//creamos un double
            double res = (9.0/5.0) * celsius + 32;//usamos formula matematica para convertir celsius a fahrenheit
            result(res);//retornamos el resultado
        }catch (Exception e){
            System.out.println(e);
        }
    }
}
//F2C, funcion F2C
class F2C extends Function{
    @Override
    protected void xFunc() throws SQLException {
        try {
            double f = value_double(0);//creamos un double
            double res = ((f - 32)*5)/9;// usamos formula matematica para convertir fahrenheit a celsius
            result(res);//retornamos el resultado
        }catch (Exception e){
            System.out.println(e);
        }
    }
}
//Factorial, funcion Factorial
class Factorial extends Function{
    @Override
    protected void xFunc() throws SQLException {
        try {
            int f = value_int(0);//creamos int
            long res = this.factorialRecursive(f);//guardamos lo que retorne la funcion factorialRecursive en un long
            result(res);// retornamos resultado
        }catch (Exception e){
            System.out.println(e);
        }
    }

    long factorialRecursive( long n )//funcion inline factorialRecursive que retorna un long
    {
        return n == 1 ? 1 : n * factorialRecursive( n-1 );//uso de operador ternario para sacar n recursivamente
    }
}
//HEX2DEC, funcion HEX2DEC
class HEX2DEC extends Function{
    @Override
    protected void xFunc() throws SQLException {
        try {
            String hex = value_text(0);//string llamada hex
            result(hex2Decimal(hex));//retornamos resultado de la funcion inline hex2Decimal
        }catch (Exception e){
            System.out.println(e);
        }
    }
    Long hex2Decimal(String s) {//funcion inline que retorna un long y recibe string de parametro
        String digits = "0123456789ABCDEF";
        s = s.toUpperCase();
        Long bigVal = new Long("0");
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            int d = digits.indexOf(c);
            Long bigD = new Long(String.valueOf(d));
            bigVal = (bigVal*16) + bigD;
        }
        return bigVal;
    }
}
//DEC2HEX, DEC2HEX
class DEC2HEX extends Function{
    @Override
    protected void xFunc() throws SQLException {
        try {
            int f = value_int(0);//creamos int
            result(Integer.toHexString(f));//casteamos int to hex string
        }catch (Exception e){
            System.out.println(e);
        }
    }
}
//COMPARESTRING,funcion COMPARESTRING
class COMPARESTRING extends Function{
    @Override
    protected void xFunc() throws SQLException {
        try {
            String s1 = value_text(0);
            String s2 = value_text(1);//dos string
            int res = s1.compareTo(s2);//hacemos un compare de ambas string y lo guardamos en un int
            if(res < 0)//si res es menor a 0 res igual a -1
                res = -1;
            else if(res > 0)//si res mayor a 0 res igual a 1
                res = 1;
            else//si res igual a 0 res igual a 0
                res = 0;
            result(res);//retornamos el resultado
        }catch (Exception e){
            System.out.println(e);
        }
    }
}
//TRIM, funcion TRIM
class TRIM extends Function{
    @Override
    protected void xFunc() throws SQLException {
        try {
            String s1 = value_text(0);
            String s2 = value_text(1);//dos strings
            result(s1.replaceAll(s2 + "+$|^" + s2 + "+",""));//retornamos resultado en el que remplazamos todos los string dos en el string uno
        }catch (Exception e){
            System.out.println(e);
        }
    }
}
//MID, no logre hacerla
