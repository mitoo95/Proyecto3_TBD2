package proyecto3;
import org.sqlite.Function;
import java.sql.*;

/**
 *
 * @author erasmo
 */
public class main {

    public static void main(String[] args) throws Exception{
        
        Connection cn = null;
        try{
            Class.forName("org.sqlite.JDBC");
            cn= DriverManager.getConnection("jdbc:sqlite:test.db");
            System.out.println("SQLite DB Connected");
            Statement statement = cn.createStatement();
            statement.setQueryTimeout(5000);
            
            //MOD
            
            //PV
            
            //BIN2DEC
            Function.create(cn, "BIN2DEC", new BIN2DEC());
            statement.execute("select BIN2DEC('10000')");
            System.out.println(statement.getResultSet().getInt(1));
            //DEC2BIN
            Function.create(cn, "DEC2BIN", new DEC2BIN());
            statement.execute("select DEC2BIN('255')");
            System.out.println(statement.getResultSet().getString(1));
            //C2F
            Function.create(cn, "C2F", new C2F());
            statement.execute("select C2F(100)");
            System.out.println(statement.getResultSet().getDouble(1));
            //F2C
            Function.create(cn, "F2C", new F2C());
            statement.execute("select F2C(212)");
            System.out.println(statement.getResultSet().getInt(1));
            //Factorial
            Function.create(cn, "Factorial", new Factorial());
            statement.execute("select Factorial(6)");
            System.out.println(statement.getResultSet().getLong(1));
            //HEX2DEC
            Function.create(cn, "HEX2DEC", new HEX2DEC());
            statement.execute("select HEX2DEC('aabbccdd')");
            System.out.println(statement.getResultSet().getLong(1));
            //DEC2HEX
            Function.create(cn, "DEC2HEX", new DEC2HEX());
            statement.execute("select DEC2HEX(15)");
            System.out.println(statement.getResultSet().getString(1));
            //COMPARESTRING
            Function.create(cn, "COMPARESTRING", new COMPARESTRING());
            statement.execute("select COMPARESTRING('App','Apaaap')");
            System.out.println(statement.getResultSet().getInt(1));
            //TRIM
            Function.create(cn, "TRIM", new TRIM());
            statement.execute("select TRIM('aahola como te llamasaa','aa')");
            System.out.println(statement.getResultSet().getString(1));
            //MID
            
        }
        catch(Exception e){
            System.out.println(e);
        }
    }
}

//MOD
            
//PV
            
//BIN2DEC
class BIN2DEC extends Function{
    @Override
    protected void xFunc() throws SQLException {
        try {
            String bin = value_text(0);
            int binario = Integer.parseInt(bin);
            int m = 0;

            int l = 0;
            int d = 0;

            while (binario != 0){

                d = binario % 10;

                d *= Math.pow(2, l++);

                binario /= 10;

                m += d;
            }
            result(m);
        }catch (Exception e){
            System.out.println(e);
        }
    }
}   
//DEC2BIN
class DEC2BIN extends Function{
    @Override
    protected void xFunc() throws SQLException {
        try {
            int decimal = value_int(0);
            result(Integer.toBinaryString(decimal));
        }catch (Exception e){
            System.out.println(e);
        }
    }
}
//C2F
class C2F extends Function{
    @Override
    protected void xFunc() throws SQLException {
        try {
            double celsius = value_double(0);
            double res = (9.0/5.0) * celsius + 32;
            result(res) ;
        }catch (Exception e){
            System.out.println(e);
        }
    }
}
//F2C
class F2C extends Function{
    @Override
    protected void xFunc() throws SQLException {
        try {
            double f = value_double(0);
            double res = ((f - 32)*5)/9;
            result(res);
        }catch (Exception e){
            System.out.println(e);
        }
    }
}
//Factorial
class Factorial extends Function{
    @Override
    protected void xFunc() throws SQLException {
        try {
            int f = value_int(0);
            long res = this.factorialRecursive(f);
            result(res);
        }catch (Exception e){
            System.out.println(e);
        }
    }

    long factorialRecursive( long n )
    {
        return n == 1 ? 1 : n * factorialRecursive( n-1 );
    }
}
//HEX2DEC
class HEX2DEC extends Function{
    @Override
    protected void xFunc() throws SQLException {
        try {
            String hex = value_text(0);
            result(hex2Decimal(hex));
        }catch (Exception e){
            System.out.println(e);
        }
    }
    Long hex2Decimal(String s) {
        String digits = "0123456789ABCDEF";
        s = s.toUpperCase();
        Long sixteen = new Long("16");
        Long bigVal = new Long("0");
        //  int val = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            int d = digits.indexOf(c);
            Long bigD = new Long(String.valueOf(d));
            bigVal = (bigVal*16) + bigD;
//            bigVal = (bigVal.multiply(sixteen)).add(bigD);
            //  val = 16 * val + d;
        }
        // return val;
        return bigVal;
    }
}
//DEC2HEX
class DEC2HEX extends Function{
    @Override
    protected void xFunc() throws SQLException {
        try {
            int f = value_int(0);
            result(Integer.toHexString(f));
        }catch (Exception e){
            System.out.println(e);
        }
    }
}
//COMPARESTRING
class COMPARESTRING extends Function{
    @Override
    protected void xFunc() throws SQLException {
        try {
            String s1 = value_text(0);
            String s2 = value_text(1);
            int res = s1.compareTo(s2);
            if(res < 0)
                res = -1;
            else if(res > 0)
                res = 1;
            else
                res = 0;
            result(res);
        }catch (Exception e){
            System.out.println(e);
        }
    }
}
//TRIM
class TRIM extends Function{
    @Override
    protected void xFunc() throws SQLException {
        try {
            String s1 = value_text(0);
            String s2 = value_text(1);
            result(s1.replaceAll(s2 + "+$|^" + s2 + "+",""));
        }catch (Exception e){
            System.out.println(e);
        }
    }
}
//MID
